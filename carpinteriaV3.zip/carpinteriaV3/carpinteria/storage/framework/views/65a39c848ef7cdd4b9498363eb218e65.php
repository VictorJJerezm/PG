
<?php $__env->startSection('contenido'); ?>
<h1>Reportes · Materiales</h1>
<?php echo $__env->make('reportes._nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="card mt-2"><div class="card-body">
  <form method="GET" class="form-row">
    <div><label>Desde</label><input type="date" name="desde" value="<?php echo e($desde); ?>"></div>
    <div><label>Hasta</label><input type="date" name="hasta" value="<?php echo e($hasta); ?>"></div>
    <div class="items-end flex"><button class="btn btn-secondary btn-sm" type="submit">Aplicar</button></div>
    <div class="items-end flex" style="margin-left:auto">
      <a class="btn btn-primary btn-sm" href="<?php echo e(route('reportes.materiales.export', compact('desde','hasta'))); ?>">Exportar CSV</a>
    </div>
  </form>
</div></div>

<div class="grid grid-2 mt-2">
  <div class="card"><div class="card-body">
    <h3>Consumo (Q) por mes <small class="muted">(según pedidos)</small></h3>
    <canvas id="chartMat" width="600" height="280"></canvas>
  </div></div>
  <div class="card"><div class="card-body">
    <h3>Top materiales</h3>
    <table class="table">
      <thead><tr><th>Material</th><th>Cant.</th><th>Subtotal</th></tr></thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $top; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($t->nombre); ?></td>
            <td><?php echo e($t->cantidad); ?></td>
            <td>Q <?php echo e(number_format($t->subtotal,2)); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="3">Sin datos.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div></div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
(() => {
  const meses = <?php echo json_encode($meses, 15, 512) ?>;
  const tot   = <?php echo json_encode($totMes, 15, 512) ?>;
  const ctx = document.getElementById('chartMat').getContext('2d');
  new Chart(ctx, { type:'line', data:{ labels: meses, datasets:[{ label:'Q', data: tot, tension:.3 }] },
    options:{ plugins:{legend:{display:false}}, scales:{y:{beginAtZero:true}} }});
})();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/reportes/materiales.blade.php ENDPATH**/ ?>