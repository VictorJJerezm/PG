
<?php $__env->startSection('contenido'); ?>
<h1>Nuevo producto</h1>
<?php if($errors->any()): ?> <div class="alert alert-bad mt-2"><?php echo e($errors->first()); ?></div> <?php endif; ?>

<div class="card mt-3">
  <div class="card-body">
    <form method="POST" action="<?php echo e(route('productos.store')); ?>" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <?php echo $__env->make('productos._form', ['modo' => 'crear'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/productos/create.blade.php ENDPATH**/ ?>