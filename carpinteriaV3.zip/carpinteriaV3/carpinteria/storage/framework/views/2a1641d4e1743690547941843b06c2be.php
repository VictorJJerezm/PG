
<?php $__env->startSection('contenido'); ?>
<h1>Nuevo proveedor</h1>

<?php if($errors->any()): ?>
  <div class="alert alert-bad mt-2"><?php echo e($errors->first()); ?></div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('proveedores.store')); ?>" class="card mt-2">
  <?php echo csrf_field(); ?>
  <div class="card-body">
    <?php echo $__env->make('proveedores._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="form-actions">
      <button class="btn btn-primary">Guardar</button>
      <a class="btn btn-secondary" href="<?php echo e(route('proveedores.index')); ?>">Cancelar</a>
    </div>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/proveedores/create.blade.php ENDPATH**/ ?>