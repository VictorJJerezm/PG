<?php
  $v = fn($c,$d='') => old($c, isset($usuario)? $usuario->{$c} : $d);
?>

<label>Nombre</label>
<input type="text" name="nombre" value="<?php echo e($v('nombre')); ?>" required>

<div class="form-row">
  <div>
    <label>Correo</label>
    <input type="email" name="correo" value="<?php echo e($v('correo')); ?>" required>
  </div>
  <div>
    <label>Teléfono (opcional)</label>
    <input type="text" name="telefono" value="<?php echo e($v('telefono')); ?>">
  </div>
</div>

<div class="form-row">
  <div>
    <label>Rol</label>
    <select name="id_rol" required>
      <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($r->id); ?>" <?php echo e((int)$v('id_rol')===$r->id ? 'selected':''); ?>>
          <?php echo e($r->nombre); ?>

        </option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div>
    <label>Estado</label>
    <?php $act = $v('activo', 1); ?>
    <select name="activo" required>
      <option value="1" <?php echo e((int)$act===1?'selected':''); ?>>Activo</option>
      <option value="0" <?php echo e((int)$act===0?'selected':''); ?>>Inactivo</option>
    </select>
  </div>
</div>

<div class="form-row">
  <div>
    <label>Contraseña <?php echo e(isset($usuario)? '(dejar en blanco para mantener)': ''); ?></label>
    <input type="password" name="contra" <?php echo e(isset($usuario)? '': 'required'); ?>>
  </div>
  <div>
    <label>Confirmar contraseña</label>
    <input type="password" name="contra_confirmation" <?php echo e(isset($usuario)? '': 'required'); ?>>
  </div>
</div>
<?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/usuarios/_form.blade.php ENDPATH**/ ?>