

<?php $__env->startSection('contenido'); ?>
<h1>Reportes</h1>
<?php echo $__env->make('reportes._nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="card mt-2">
  <div class="card-body">
    <form method="GET" class="form-row">
      <div>
        <label>Desde</label>
        <input type="date" name="desde" value="<?php echo e($desde); ?>">
      </div>
      <div>
        <label>Hasta</label>
        <input type="date" name="hasta" value="<?php echo e($hasta); ?>">
      </div>
      <div class="items-end flex">
        <button class="btn btn-secondary btn-sm" type="submit">Aplicar</button>
      </div>
      <div class="items-end flex" style="margin-left:auto">
        <a class="btn btn-primary btn-sm" href="<?php echo e(route('reportes.export', compact('desde','hasta'))); ?>">Exportar ingresos (CSV)</a>
      </div>
    </form>
  </div>
</div>


<div class="grid grid-3 mt-2">
  <div class="card"><div class="card-body">
    <h3>Cotizaciones</h3>
    <div class="muted">Total: <?php echo e($cTotal); ?></div>
    <div class="mt-1">Pendientes: <strong><?php echo e($cPend); ?></strong></div>
    <div>Respondidas: <strong><?php echo e($cResp); ?></strong></div>
    <div>Aprobadas: <strong><?php echo e($cApr); ?></strong></div>
    <div>Rechazadas: <strong><?php echo e($cRech); ?></strong></div>
    <div>Canceladas: <strong><?php echo e($cCanc); ?></strong></div>
    <div class="mt-1">Tasa aprobación (sobre respondidas): <strong><?php echo e($tasaAprob); ?>%</strong></div>
  </div></div>

  <div class="card"><div class="card-body">
    <h3>Pedidos</h3>
    <div class="muted">Total: <?php echo e($pTot); ?></div>
    <div class="mt-1">En proceso: <strong><?php echo e($pProc); ?></strong></div>
    <div>Terminado: <strong><?php echo e($pTerm); ?></strong></div>
    <div>Entregado: <strong><?php echo e($pEnt); ?></strong></div>
  </div></div>

  <div class="card"><div class="card-body">
    <h3>Ingresos</h3>
    <div class="muted">Rango: <?php echo e($desde); ?> → <?php echo e($hasta); ?></div>
    <div class="mt-2" style="font-size:1.4rem"><strong>Q <?php echo e(number_format($ingresosTotales,2)); ?></strong></div>
  </div></div>
</div>


<div class="grid grid-2 mt-2">
  <div class="card"><div class="card-body">
    <h3>Ingresos por mes</h3>
    <canvas id="chartIngresos" width="600" height="280"></canvas>
  </div></div>

  <div class="card"><div class="card-body">
    <h3>Distribución de cotizaciones</h3>
    <canvas id="chartCot" width="600" height="280"></canvas>
  </div></div>
</div>


<div class="grid grid-2 mt-2">
  <div class="card"><div class="card-body">
    <h3>Top productos</h3>
    <table class="table">
      <thead><tr><th>Producto</th><th>Cant.</th><th>Subtotal</th></tr></thead>
      <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $topProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><?php echo e($t->nombre); ?></td>
          <td><?php echo e($t->cantidad); ?></td>
          <td>Q <?php echo e(number_format($t->subtotal,2)); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="3">Sin datos.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div></div>

  <div class="card"><div class="card-body">
    <h3>Top materiales</h3>
    <table class="table">
      <thead><tr><th>Material</th><th>Cant.</th><th>Subtotal</th></tr></thead>
      <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $topMateriales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><?php echo e($t->nombre); ?></td>
          <td><?php echo e($t->cantidad); ?></td>
          <td>Q <?php echo e(number_format($t->subtotal,2)); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="3">Sin datos.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div></div>
</div>

<div class="card mt-2"><div class="card-body">
  <h3>Clientes con más cotizaciones</h3>
  <table class="table">
    <thead><tr><th>Cliente</th><th>Correo</th><th># Cotizaciones</th></tr></thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $topClientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <tr>
        <td><?php echo e($t->nombre); ?></td>
        <td class="muted"><?php echo e($t->correo); ?></td>
        <td><strong><?php echo e($t->total); ?></strong></td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <tr><td colspan="3">Sin datos.</td></tr>
    <?php endif; ?>
    </tbody>
  </table>
</div></div>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  (() => {
    const meses = <?php echo json_encode($meses, 15, 512) ?>;
    const ingresos = <?php echo json_encode($ingresos, 15, 512) ?>;

    const ctx1 = document.getElementById('chartIngresos').getContext('2d');
    new Chart(ctx1, {
      type: 'line',
      data: {
        labels: meses,
        datasets: [{
          label: 'Ingresos (Q)',
          data: ingresos,
          tension: 0.3
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false }},
        scales: { y: { beginAtZero: true } }
      }
    });

    const cotData = {
      labels: ['Pendiente','Respondida','Aprobada','Rechazada','Cancelada'],
      values: [<?php echo e($cPend); ?>, <?php echo e($cResp); ?>, <?php echo e($cApr); ?>, <?php echo e($cRech); ?>, <?php echo e($cCanc); ?>]
    };

    const ctx2 = document.getElementById('chartCot').getContext('2d');
    new Chart(ctx2, {
      type: 'bar',
      data: {
        labels: cotData.labels,
        datasets: [{ label: 'Cotizaciones', data: cotData.values }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false }},
        scales: { y: { beginAtZero: true } }
      }
    });
  })();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/reportes/index.blade.php ENDPATH**/ ?>