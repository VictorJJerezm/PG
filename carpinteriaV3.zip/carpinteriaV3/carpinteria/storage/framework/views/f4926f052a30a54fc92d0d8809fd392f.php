

<?php $__env->startSection('contenido'); ?>
<h1>Panel</h1>
<p class="muted">Bienvenido, <?php echo e(auth()->user()->nombre); ?>.</p>

<div class="grid grid-3 mt-3">
  <a class="card" href="<?php echo e(route('productos.index')); ?>"><div class="card-body"><h3>Productos</h3><p class="muted">Gestiona el catálogo</p></div></a>
  <a class="card" href="<?php echo e(route('insumos.index')); ?>"><div class="card-body"><h3>Insumos</h3><p class="muted">CRUD de insumos</p></div></a>
  <a class="card" href="<?php echo e(route('inventario.index')); ?>"><div class="card-body"><h3>Inventario</h3><p class="muted">Entradas / Salidas</p></div></a>
  <a class="card" href="<?php echo e(route('gestion.cotizaciones.index')); ?>"><div class="card-body"><h3>Cotizaciones</h3><p class="muted">Ver cotizaciones</p></div></a>
  <a class="card" href="<?php echo e(route('pedidos.index')); ?>"><div class="card-body"><h3>Pedidos</h3><p class="muted">Ver pedidos</p></div></a>
  <a class="card" href="<?php echo e(route('usuarios.index')); ?>"><div class="card-body"><h3>Gestión de Usuarios</h3><p class="muted">Gestión de Usuarios</p></div></a>
  <a class="card" href="<?php echo e(route('reportes.index')); ?>"><div class="card-body"><h3>Reportes</h3><p class="muted">Metricas y Reportería</p></div></a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/panel/dashboard.blade.php ENDPATH**/ ?>