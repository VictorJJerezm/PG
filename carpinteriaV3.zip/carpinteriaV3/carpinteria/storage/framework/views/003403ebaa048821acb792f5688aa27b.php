<div class="tabs mt-2">
  <a href="<?php echo e(route('reportes.index')); ?>"      class="<?php echo e(request()->routeIs('reportes.index') ? 'active' : ''); ?>">General</a> -
  <a href="<?php echo e(route('reportes.materiales')); ?>" class="<?php echo e(request()->routeIs('reportes.materiales') ? 'active' : ''); ?>">Materiales</a> -
  <a href="<?php echo e(route('reportes.insumos')); ?>"    class="<?php echo e(request()->routeIs('reportes.insumos') ? 'active' : ''); ?>">Insumos</a> -
  <a href="<?php echo e(route('reportes.clientes')); ?>"   class="<?php echo e(request()->routeIs('reportes.clientes') ? 'active' : ''); ?>">Clientes</a>
</div><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/reportes/_nav.blade.php ENDPATH**/ ?>