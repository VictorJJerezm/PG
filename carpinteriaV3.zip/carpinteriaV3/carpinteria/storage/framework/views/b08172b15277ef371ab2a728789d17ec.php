
<?php $__env->startSection('contenido'); ?>
<h1>Nuevo usuario</h1>

<?php if($errors->any()): ?> <div class="alert alert-bad mt-2"><?php echo e($errors->first()); ?></div> <?php endif; ?>

<div class="card mt-2"><div class="card-body">
  <form method="POST" action="<?php echo e(route('usuarios.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php echo $__env->make('usuarios._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="form-actions">
      <button class="btn btn-primary" type="submit">Guardar</button>
      <a class="btn btn-secondary" href="<?php echo e(route('usuarios.index')); ?>">Cancelar</a>
    </div>
  </form>
</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/usuarios/create.blade.php ENDPATH**/ ?>