
<?php $__env->startSection('contenido'); ?>
<h1>Usuarios</h1>

<?php if(session('ok')): ?> <div class="alert alert-ok mt-2"><?php echo e(session('ok')); ?></div> <?php endif; ?>
<?php if($errors->any()): ?> <div class="alert alert-bad mt-2"><?php echo e($errors->first()); ?></div> <?php endif; ?>

<div class="card mt-2">
  <div class="card-body">
    <form method="GET" class="form-row">
      <div>
        <label>Buscar</label>
        <input type="text" name="q" value="<?php echo e($q); ?>" placeholder="Nombre o correo">
      </div>
      <div>
        <label>Rol</label>
        <select name="rol">
          <option value="">— Todos —</option>
          <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($r->id); ?>" <?php echo e((string)$rol===(string)$r->id?'selected':''); ?>><?php echo e($r->nombre); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div>
        <label>Estado</label>
        <select name="estado">
          <option value="">— Todos —</option>
          <option value="Activo"   <?php echo e($estado==='Activo'?'selected':''); ?>>Activo</option>
          <option value="Inactivo" <?php echo e($estado==='Inactivo'?'selected':''); ?>>Inactivo</option>
        </select>
      </div>
      <div class="items-end flex">
        <button class="btn btn-secondary btn-sm" type="submit">Filtrar</button>
      </div>
      <div class="items-end flex" style="margin-left:auto">
        <a class="btn btn-primary btn-sm" href="<?php echo e(route('usuarios.create')); ?>">Nuevo</a>
      </div>
    </form>
  </div>
</div>

<div class="card mt-2">
  <div class="card-body">
    <table class="table">
      <thead>
        <tr>
          <th>#</th><th>Nombre</th><th>Correo</th><th>Rol</th><th>Estado</th><th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php
            $badge = $u->activo ? 'badge-ok' : 'badge-bad';
            $estadoTxt = $u->activo ? 'Activo' : 'Inactivo';
          ?>
          <tr>
            <td><?php echo e($u->id); ?></td>
            <td><?php echo e($u->nombre); ?></td>
            <td class="muted"><?php echo e($u->correo); ?></td>
            <td><?php echo e($u->rol?->nombre ?? '—'); ?></td>
            <td><span class="badge <?php echo e($badge); ?>"><?php echo e($estadoTxt); ?></span></td>
            <td class="actions">
              <a class="btn btn-secondary btn-sm" href="<?php echo e(route('usuarios.edit', $u->id)); ?>">Editar</a>

              <?php if($u->activo): ?>
                <form method="POST" action="<?php echo e(route('usuarios.desactivar', $u->id)); ?>" style="display:inline" onsubmit="return confirm('¿Desactivar usuario?')">
                  <?php echo csrf_field(); ?>
                  <button class="btn btn-warning btn-sm" type="submit">Desactivar</button>
                </form>
              <?php else: ?>
                <form method="POST" action="<?php echo e(route('usuarios.activar', $u->id)); ?>" style="display:inline" onsubmit="return confirm('¿Activar usuario?')">
                  <?php echo csrf_field(); ?>
                  <button class="btn btn-primary btn-sm" type="submit">Activar</button>
                </form>
              <?php endif; ?>

              <form method="POST" action="<?php echo e(route('usuarios.destroy', $u->id)); ?>" style="display:inline" onsubmit="return confirm('¿Eliminar usuario? Esta acción no se puede deshacer.')">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-danger btn-sm" type="submit">Eliminar</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6">Sin usuarios.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/usuarios/index.blade.php ENDPATH**/ ?>