<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title><?php echo e(config('app.name', 'Carpintería')); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
  <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
</head>
<body>

<header class="navbar">
  <div class="container row">
    <a class="brand" href="<?php echo e(route('catalogo.index')); ?>">Carpintería</a>

   <nav>
    
    <a href="<?php echo e(route('catalogo.index')); ?>" class="<?php echo e(request()->routeIs('catalogo.index') ? 'active' : ''); ?>">Catálogo</a>

    <?php if(auth()->guard()->check()): ?>
      
      <?php if(auth()->user()->esCliente()): ?>
        <a href="<?php echo e(route('cliente.cotizaciones.mis')); ?>" class="<?php echo e(request()->routeIs('cliente.cotizaciones.*') ? 'active' : ''); ?>">Mis cotizaciones</a>
      <?php endif; ?>

      
      <?php if(auth()->user()->esAdmin() || auth()->user()->esCarpintero()): ?>

        
        <a href="<?php echo e(route('panel.dashboard')); ?>" class="<?php echo e(request()->routeIs('panel.*') ? 'active' : ''); ?>">Panel</a>

        
        <?php if(auth()->user()->esAdmin()): ?>
          <a href="<?php echo e(route('usuarios.index')); ?>" class="<?php echo e(request()->routeIs('usuarios.*') ? 'active' : ''); ?>">Usuarios</a>
        <?php endif; ?>

        <?php
          $isProduccionActive = request()->routeIs('productos.*','insumos.*','inventario.*','proveedores.*');
          $isComercialActive  = request()->routeIs('pedidos.*','gestion.cotizaciones.*');
          $isReportesActive   = request()->routeIs('reportes.*');
        ?>

        
        <details class="dropdown <?php echo e($isProduccionActive ? 'active' : ''); ?>">
          <summary class="dropdown-toggle">Producción</summary>
          <div class="dropdown-menu">
            <a href="<?php echo e(route('productos.index')); ?>"            class="<?php echo e(request()->routeIs('productos.*') ? 'active' : ''); ?>">Productos</a>
            <a href="<?php echo e(route('insumos.index')); ?>"              class="<?php echo e(request()->routeIs('insumos.*') ? 'active' : ''); ?>">Insumos</a>
            <a href="<?php echo e(route('inventario.index')); ?>"           class="<?php echo e(request()->routeIs('inventario.*') ? 'active' : ''); ?>">Inventario</a>

            <?php if(\Illuminate\Support\Facades\Route::has('proveedores.index')): ?>
              <a href="<?php echo e(route('proveedores.index')); ?>"        class="<?php echo e(request()->routeIs('proveedores.*') ? 'active' : ''); ?>">Proveedores</a>
            <?php else: ?>
              <span class="dropdown-item muted" title="Próximamente">Proveedores</span>
            <?php endif; ?>
          </div>
        </details>

        
        <details class="dropdown <?php echo e($isComercialActive ? 'active' : ''); ?>">
          <summary class="dropdown-toggle">Pedidos y cotizaciones</summary>
          <div class="dropdown-menu">
            <a href="<?php echo e(route('pedidos.index')); ?>"              class="<?php echo e(request()->routeIs('pedidos.*') ? 'active' : ''); ?>">Pedidos</a>
            <a href="<?php echo e(route('gestion.cotizaciones.index')); ?>" class="<?php echo e(request()->routeIs('gestion.cotizaciones.*') ? 'active' : ''); ?>">Cotizaciones</a>
          </div>
        </details>

        
        <details class="dropdown <?php echo e($isReportesActive ? 'active' : ''); ?>">
          <summary class="dropdown-toggle">Reportes</summary>
          <div class="dropdown-menu">
            <a href="<?php echo e(route('reportes.index')); ?>"      class="<?php echo e(request()->routeIs('reportes.index') ? 'active' : ''); ?>">General</a>
            <a href="<?php echo e(route('reportes.materiales')); ?>" class="<?php echo e(request()->routeIs('reportes.materiales') ? 'active' : ''); ?>">Materiales</a>
            <a href="<?php echo e(route('reportes.insumos')); ?>"    class="<?php echo e(request()->routeIs('reportes.insumos') ? 'active' : ''); ?>">Insumos</a>
            <a href="<?php echo e(route('reportes.clientes')); ?>"   class="<?php echo e(request()->routeIs('reportes.clientes') ? 'active' : ''); ?>">Clientes</a>
          </div>
        </details>
      <?php endif; ?>
    <?php endif; ?>
  </nav>

    <div class="spacer"></div>

    <?php if(auth()->guard()->check()): ?>
      <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-secondary btn-sm">Salir</button>
      </form>
    <?php endif; ?>

    <?php if(auth()->guard()->guest()): ?>
      <a href="<?php echo e(route('register')); ?>" class="btn btn-secondary btn-sm">Crear cuenta</a>
      <a href="<?php echo e(route('login')); ?>" class="btn btn-primary btn-sm">Ingresar</a>
    <?php endif; ?>
  </div>
</header>

<main class="section">
  <div class="container">
    <?php echo $__env->yieldContent('contenido'); ?>
  </div>
</main>

<footer class="footer">
  <div class="container muted">© <?php echo e(date('Y')); ?> Carpintería — Gestión y cotizaciones</div>
</footer>
<script>
    document.addEventListener("DOMContentLoaded", () => {
      document.querySelectorAll("details.dropdown").forEach((el) => {
        el.addEventListener("toggle", () => {
          if (el.open) {
            document.querySelectorAll("details.dropdown").forEach((other) => {
              if (other !== el) other.removeAttribute("open");
            });
          }
        });
      });
    });
  </script>

</body>
</html><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/layouts/app.blade.php ENDPATH**/ ?>