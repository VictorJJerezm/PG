
<?php $__env->startSection('contenido'); ?>
<h1>Reportes · Clientes</h1>
<?php echo $__env->make('reportes._nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="card mt-2"><div class="card-body">
  <form method="GET" class="form-row">
    <div><label>Desde</label><input type="date" name="desde" value="<?php echo e($desde); ?>"></div>
    <div><label>Hasta</label><input type="date" name="hasta" value="<?php echo e($hasta); ?>"></div>
    <div class="items-end flex"><button class="btn btn-secondary btn-sm" type="submit">Aplicar</button></div>
    <div class="items-end flex" style="margin-left:auto">
      <a class="btn btn-primary btn-sm" href="<?php echo e(route('reportes.clientes.export', compact('desde','hasta'))); ?>">Exportar CSV</a>
    </div>
  </form>
</div></div>

<div class="card mt-2"><div class="card-body">
  <table class="table">
    <thead>
      <tr><th>Cliente</th><th>Correo</th><th>Cotizaciones</th><th>Aprobadas</th><th>Pedidos</th><th>Monto (Q)</th></tr>
    </thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><?php echo e($c->nombre); ?></td>
          <td class="muted"><?php echo e($c->correo); ?></td>
          <td><?php echo e($c->cot_total); ?></td>
          <td><?php echo e($c->cot_aprobadas); ?></td>
          <td><?php echo e($c->pedidos); ?></td>
          <td><strong><?php echo e(number_format($c->monto,2)); ?></strong></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="6">Sin datos.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/reportes/clientes.blade.php ENDPATH**/ ?>