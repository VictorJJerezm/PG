
<?php $__env->startSection('contenido'); ?>
<h1>Pedidos</h1>

<div class="form-actions">
  <a href="<?php echo e(route('pedidos.index')); ?>" class="btn btn-secondary btn-sm">Todos</a>
  <?php $__currentLoopData = ['En proceso','Terminado','Entregado']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('pedidos.index',['estado'=>$st])); ?>" class="btn btn-secondary btn-sm"><?php echo e($st); ?></a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php if(session('ok')): ?> <div class="alert alert-ok mt-2"><?php echo e(session('ok')); ?></div> <?php endif; ?>
<?php if($errors->any()): ?> <div class="alert alert-bad mt-2"><?php echo e($errors->first()); ?></div> <?php endif; ?>

<div class="card mt-3">
  <div class="card-body">
    <table class="table">
      <thead>
        <tr>
          <th>#</th><th>Cliente</th><th>Estado</th><th>Total</th><th>Detalle</th><th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($p->id_pedido); ?></td>
            <td><?php echo e($p->cliente?->nombre); ?></td>
            <td>
              <?php
                $badge = match($p->estado){
                  'En proceso' => 'badge-warn',
                  'Terminado'  => 'badge-neutral',
                  'Entregado'  => 'badge-ok',
                  default      => 'badge-neutral'
                };
              ?>
              <span class="badge <?php echo e($badge); ?>"><?php echo e($p->estado); ?></span>
            </td>
            <td><strong>Q <?php echo e(number_format($p->total,2)); ?></strong></td>
            <td>
              <?php $__currentLoopData = $p->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center gap-2">
                  <?php if($d->producto?->foto_url): ?>
                    <img src="<?php echo e($d->producto->foto_url); ?>" class="thumb-xs" alt="foto">
                  <?php endif; ?>
                  <div><?php echo e($d->producto?->nombre); ?> <?php if($d->material): ?> — <small class="muted"><?php echo e($d->material->nombre); ?></small><?php endif; ?> × <?php echo e($d->cantidad); ?></div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td class="actions">
              <a class="btn btn-secondary btn-sm" href="<?php echo e(route('pedidos.show',$p->id_pedido)); ?>">Ver</a>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6">No hay pedidos.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/pedidos/index.blade.php ENDPATH**/ ?>