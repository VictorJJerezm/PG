<?php
  // helper de valores del producto
  $v = fn($campo, $def = '') => old($campo, isset($producto) ? $producto->{$campo} : $def);

  // seleccionados (cuando editas) -> mapa por id_insumo
  $seleccionados = isset($producto) ? $producto->materiales->keyBy('id_insumo') : collect();

  // ids seleccionados (para reconstruir tras validación fallida o precargar en edición)
  $seleccionadosIds = collect(old('materiales', $seleccionados->keys()->all()));

  // recargos tras validación fallida
  $recargosOld = old('recargos', []);

  // recargos al editar (si no hay old)
  $recargosEdit = isset($producto)
      ? $producto->materiales->mapWithKeys(fn($m) => [$m->id_insumo => $m->pivot->recargo ?? 0])->all()
      : [];
?>

<label>Nombre</label>
<input type="text" name="nombre" value="<?php echo e($v('nombre')); ?>" required>

<label>Descripción</label>
<textarea name="descripcion"><?php echo e($v('descripcion')); ?></textarea>

<div class="form-row">
  <div>
    <label>Precio estimado (base)</label>
    <input type="number" step="0.01" name="precio_estimado" value="<?php echo e($v('precio_estimado')); ?>">
  </div>
  <div>
    <label>Estado</label>
    <?php $est = $v('estado','Activo'); ?>
    <select name="estado">
      <option value="Activo"   <?php echo e($est==='Activo'?'selected':''); ?>>Activo</option>
      <option value="Inactivo" <?php echo e($est==='Inactivo'?'selected':''); ?>>Inactivo</option>
    </select>
  </div>
</div>

<label>Foto (opcional)</label>
<input type="file" name="foto" accept="image/*">

<?php if(isset($producto) && $producto->foto_url): ?>
  <div class="mt-2">
    <small class="muted">Vista previa:</small><br>
    <img src="<?php echo e($producto->foto_url); ?>" alt="Foto <?php echo e($producto->nombre); ?>" style="width:260px; height:160px; object-fit:cover; border-radius:8px;">
  </div>
<?php endif; ?>

<h3 class="mt-3">Materiales permitidos</h3>
<p class="muted">Selecciona materiales para este producto y define un recargo opcional en quetzales (Q).</p>

<div class="card mt-2">
  <div class="card-body">
    <?php if(isset($materiales) && $materiales->count()): ?>
      <div class="form-row">
        <div>
          <label>Agregar material</label>
          <select id="material_selector">
            <option value="">— Seleccione —</option>
            <?php $__currentLoopData = $materiales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($m->id_insumo); ?>"><?php echo e($m->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="items-end flex">
          <button type="button" class="btn btn-secondary btn-sm" id="add_material">Agregar</button>
        </div>
      </div>

      <div class="mt-2">
        <table class="table" id="mat_table">
          <thead>
            <tr>
              <th>Material</th>
              <th>Recargo (Q)</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $materiales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($seleccionadosIds->contains($m->id_insumo)): ?>
                <?php
                  $rid = $m->id_insumo;
                  $valorRecargo = array_key_exists($rid, $recargosOld)
                                    ? $recargosOld[$rid]
                                    : ($recargosEdit[$rid] ?? 0);
                ?>
                <tr data-id="<?php echo e($rid); ?>">
                  <td>
                    <?php echo e($m->nombre); ?>

                    <input type="hidden" name="materiales[]" value="<?php echo e($rid); ?>">
                  </td>
                  <td>
                    <input type="number" step="0.01" name="recargos[<?php echo e($rid); ?>]" value="<?php echo e($valorRecargo); ?>">
                  </td>
                  <td>
                    <button type="button" class="btn btn-danger btn-sm js-remove">Quitar</button>
                  </td>
                </tr>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <div class="alert alert-warn">No hay materiales activos (insumos.categoria = "material").</div>
    <?php endif; ?>
  </div>
</div>

<div class="form-actions">
  <button type="submit" class="btn btn-primary"><?php echo e(($modo ?? '')==='editar' ? 'Actualizar' : 'Guardar'); ?></button>
  <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-secondary">Cancelar</a>
</div>

<script>
(() => {
  const sel   = document.getElementById('material_selector');
  const add   = document.getElementById('add_material');
  const tbody = document.querySelector('#mat_table tbody');

  if (!sel || !add || !tbody) return;

  function yaExiste(id){ return !!tbody.querySelector(`tr[data-id="${id}"]`); }

  add.addEventListener('click', () => {
    const id = sel.value;
    const text = sel.options[sel.selectedIndex]?.text || '';
    if (!id) return;
    if (yaExiste(id)) return;

    const tr = document.createElement('tr');
    tr.setAttribute('data-id', id);
    tr.innerHTML = `
      <td>${text} <input type="hidden" name="materiales[]" value="${id}"></td>
      <td><input type="number" step="0.01" name="recargos[${id}]" value="0"></td>
      <td><button type="button" class="btn btn-danger btn-sm js-remove">Quitar</button></td>
    `;
    tbody.appendChild(tr);
  });

  tbody.addEventListener('click', (e) => {
    const btn = e.target.closest('.js-remove');
    if (!btn) return;
    btn.closest('tr')?.remove();
  });
})();
</script>
<?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/productos/_form.blade.php ENDPATH**/ ?>