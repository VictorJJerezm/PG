<?php $v = fn($c,$d='')=> old($c, $proveedor->{$c} ?? $d); ?>

<label>Nombre</label>
<input type="text" name="nombre" value="<?php echo e($v('nombre')); ?>" required>

<label>Correo</label>
<input type="email" name="correo" value="<?php echo e($v('correo')); ?>" required>

<div class="form-row">
  <div>
    <label>Teléfono</label>
    <input type="text" name="telefono" value="<?php echo e($v('telefono')); ?>">
  </div>
  <div>
    <label>Empresa</label>
    <input type="text" name="empresa" value="<?php echo e($v('empresa')); ?>">
  </div>
</div>

<label>Etiquetas <small class="muted">(separadas por coma)</small></label>
<input type="text" name="etiquetas" value="<?php echo e($v('etiquetas')); ?>" placeholder="maderas, ferretería, barnices">

<label>Notas</label>
<textarea name="notas" rows="4"><?php echo e($v('notas')); ?></textarea>

<label class="mt-1">
  <input type="checkbox" name="activo" value="1" <?php echo e($v('activo', true) ? 'checked' : ''); ?>>
  Activo
</label><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/proveedores/_form.blade.php ENDPATH**/ ?>