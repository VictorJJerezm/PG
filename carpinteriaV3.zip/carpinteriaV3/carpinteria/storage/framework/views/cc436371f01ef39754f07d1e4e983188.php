
<?php $__env->startSection('contenido'); ?>
<h1>Conversación con <?php echo e($proveedor->nombre); ?></h1>
<div class="muted"><?php echo e($proveedor->correo); ?> — <?php echo e($proveedor->empresa ?? 'Proveedor'); ?></div>

<div class="grid grid-3 mt-2">
  <div class="card"><div class="card-body">
    <div class="muted">Mensajes enviados</div>
    <div style="font-size:1.6rem"><strong><?php echo e($total); ?></strong></div>
  </div></div>
  <div class="card"><div class="card-body">
    <div class="muted">Último envío</div>
    <div><strong><?php echo e($ultimo?->fecha?->format('Y-m-d H:i') ?? '—'); ?></strong></div>
  </div></div>
</div>


<div class="card mt-2">
  <div class="card-body" style="max-height:480px; overflow:auto; background:#fafafa">
    <?php $__empty_1 = true; $__currentLoopData = $mensajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div style="display:flex; margin:.5rem 0; justify-content:flex-end">
        <div style="max-width:70%; padding:.6rem .8rem; border-radius:12px; background:#e3f2fd;
                    box-shadow:0 1px 3px rgba(0,0,0,.08)">
          <div style="font-size:.85rem; color:#6b7280; margin-bottom:.25rem">
            Tú — <?php echo e($m->fecha->format('Y-m-d H:i')); ?>

          </div>
          <div style="font-weight:600"><?php echo e($m->asunto); ?></div>
          <div class="mt-1" style="white-space:pre-wrap"><?php echo nl2br(e($m->cuerpo)); ?></div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <div class="muted">Aún no has enviado mensajes a este proveedor.</div>
    <?php endif; ?>
  </div>
</div>


<div class="card mt-2">
  <div class="card-body">
    <h3>Enviar mensaje</h3>
    <?php if($errors->any()): ?> <div class="alert alert-bad mt-2"><?php echo e($errors->first()); ?></div> <?php endif; ?>
    <form method="POST" action="<?php echo e(route('proveedores.conversacion.enviar', $proveedor->id_proveedor)); ?>">
      <?php echo csrf_field(); ?>
      <label>Asunto</label>
      <input type="text" name="asunto" value="<?php echo e(old('asunto')); ?>" required>

      <label>Mensaje</label>
      <textarea name="mensaje" rows="8" required><?php echo e(old('mensaje')); ?></textarea>

      <label>CC (opcional)</label>
      <input type="email" name="cc" value="<?php echo e(old('cc')); ?>">

      <div class="form-actions">
        <button class="btn btn-primary">Enviar</button>
        <a href="<?php echo e(route('proveedores.index')); ?>" class="btn btn-secondary">Volver</a>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/proveedores/conversacion.blade.php ENDPATH**/ ?>