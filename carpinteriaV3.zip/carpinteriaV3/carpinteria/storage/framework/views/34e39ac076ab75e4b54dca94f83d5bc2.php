
<?php $__env->startSection('contenido'); ?>
<h1>Inventario</h1>

<?php if(session('ok')): ?> <div class="alert alert-ok mt-2"><?php echo e(session('ok')); ?></div> <?php endif; ?>
<?php if($errors->any()): ?> <div class="alert alert-bad mt-2"><?php echo e($errors->first()); ?></div> <?php endif; ?>

<div class="card mt-3">
  <div class="card-body">
    <table class="table">
      <thead>
        <tr>
          <th>Insumo</th><th>Stock</th><th>Mínimo</th><th>Actualizado</th><th>Entrada</th><th>Salida</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $insumos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php
            $inv = $i->inventario;
            $stock = $inv?->cantidad ?? 0;
            $min = $inv?->stock_minimo ?? 5;
          ?>
          <tr>
            <td><?php echo e($i->nombre); ?></td>
            <td>
              <?php echo e($stock); ?>

              <?php if($stock < $min): ?> <span class="badge badge-bad">Bajo</span> <?php endif; ?>
            </td>
            <td><?php echo e($min); ?></td>
            <td><?php echo e($inv?->fecha_actualizacion ?? '—'); ?></td>
            <td>
              <form method="POST" action="<?php echo e(route('inventario.entrada', $i->id_insumo)); ?>" class="flex gap-2">
                <?php echo csrf_field(); ?>
                <input type="number" name="cantidad" min="1" required placeholder="cant.">
                <input type="number" step="0.01" name="costo_unitario" required placeholder="costo">
                <input type="text" name="nota" placeholder="nota (opcional)">
                <button type="submit" class="btn btn-primary btn-sm">+ Entrar</button>
              </form>
            </td>
            <td>
              <form method="POST" action="<?php echo e(route('inventario.salida', $i->id_insumo)); ?>" class="flex gap-2">
                <?php echo csrf_field(); ?>
                <input type="number" name="cantidad" min="1" required placeholder="cant.">
                <input type="text" name="nota" placeholder="nota (opcional)">
                <button type="submit" class="btn btn-secondary btn-sm">− Salida</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6">No hay insumos</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>


<div class="card mt-3">
  <div class="card-body">

    <div class="form-row" style="align-items:flex-end">
      <div>
        <label>Filtrar por insumo</label>
        <form method="GET" action="<?php echo e(route('inventario.index')); ?>" class="form-row">
          <select name="insumo" onchange="this.form.submit()">
            <option value="0">— Todos —</option>
            <?php $__currentLoopData = $insumosFiltro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($inf->id_insumo); ?>" <?php echo e((int)$insumoSel===(int)$inf->id_insumo ? 'selected':''); ?>>
                <?php echo e($inf->nombre); ?>

              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <label style="margin-left:1rem">Mostrar</label>
          <select name="limite" onchange="this.form.submit()">
            <?php $__currentLoopData = [5,10,25,50,100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($n); ?>" <?php echo e((int)$limite===$n ? 'selected':''); ?>><?php echo e($n); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </form>
      </div>

      <div class="spacer"></div>
      
      
    </div>

    <h3 class="mt-2">Movimientos recientes</h3>

    <table class="table mt-1">
      <thead>
        <tr>
          <th>Fecha</th>
          <th>Insumo</th>
          <th>Tipo</th>
          <th class="text-right">Cantidad</th>
          <th class="text-right">Costo unit.</th>
          <th class="text-right">Importe</th>
          <th>Nota</th>
          <th>Usuario</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $movimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php
            $isEntrada = strtolower($m->tipo) === 'entrada';
            $badge = $isEntrada ? 'badge-ok' : 'badge-bad';
            $cant  = ($isEntrada ? '+' : '−') . (int)$m->cantidad;
            $costo = $m->costo_unitario !== null ? number_format($m->costo_unitario,2) : '—';
            $importe = $isEntrada && $m->costo_unitario !== null
                      ? $m->cantidad * $m->costo_unitario
                      : 0;
          ?>
          <tr>
            <td><?php echo e(\Illuminate\Support\Str::of($m->fecha)->limit(16,'')); ?></td>
            <td><?php echo e($m->insumo); ?></td>
            <td><span class="badge <?php echo e($badge); ?>"><?php echo e(ucfirst($m->tipo)); ?></span></td>
            <td class="text-right"><?php echo e($cant); ?></td>
            <td class="text-right"><?php echo e($costo === '—' ? '—' : 'Q '.$costo); ?></td>
            <td class="text-right"><?php echo e($importe ? 'Q '.number_format($importe,2) : '—'); ?></td>
            <td class="muted"><?php echo e($m->nota); ?></td>
            <td class="muted"><?php echo e($m->usuario ?? '—'); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="8">Sin movimientos.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/inventario/index.blade.php ENDPATH**/ ?>