

<?php $__env->startSection('contenido'); ?>
<div class="grid grid-2">
  <div class="card">
    <div class="card-body">
      <h1>Iniciar sesión</h1>
      <p class="muted">Ingrese sus credenciales para continuar.</p>

      <?php if(session('info')): ?>
        <div class="alert alert-warn mt-2"><?php echo e(session('info')); ?></div>
      <?php endif; ?>

      <?php if($errors->any()): ?>
        <div class="alert alert-bad mt-2"><?php echo e($errors->first()); ?></div>
      <?php endif; ?>

      <form method="POST" action="<?php echo e(route('login.procesar')); ?>" class="mt-3">
        <?php echo csrf_field(); ?>
        <label>Correo</label>
        <input type="email" name="correo" value="<?php echo e(old('correo')); ?>" required>

        <label>Contraseña</label>
        <input type="password" name="contra" required>

        <div class="form-actions">
          <button type="submit" class="btn btn-primary">Entrar</button>
          <a href="<?php echo e(route('register')); ?>" class="btn btn-secondary">Crear cuenta</a>
        </div>
      </form>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <h2>Accesos de prueba</h2>
      <ul class="mt-2">
        <li><strong>Admin:</strong> admin@demo.com / Admin12345</li>
        <li><strong>Cliente:</strong> cliente@demo.com / Cliente12345</li>
      </ul>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/auth/login.blade.php ENDPATH**/ ?>