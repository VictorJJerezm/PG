
<?php $__env->startSection('contenido'); ?>
<h1>Proveedores</h1>

<div class="card mt-2">
  <div class="card-body">
    <form method="GET" class="form-row">
      <div>
        <label>Búsqueda</label>
        <input type="text" name="q" value="<?php echo e($q); ?>" placeholder="Nombre, empresa, correo...">
      </div>
      <div>
        <label>Etiqueta</label>
        <input type="text" name="tag" value="<?php echo e($tag); ?>" list="lista-etiquetas" placeholder="maderas, ferretería...">
        <datalist id="lista-etiquetas">
          <?php $__currentLoopData = $todasEtiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $et => $cnt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($et); ?>"><?php echo e($et); ?> (<?php echo e($cnt); ?>)</option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </datalist>
      </div>
      <div>
        <label>Estado</label>
        <select name="activo">
          <option value="todos" <?php echo e($act==='todos'?'selected':''); ?>>Todos</option>
          <option value="1"     <?php echo e($act==='1'    ?'selected':''); ?>>Activos</option>
          <option value="0"     <?php echo e($act==='0'    ?'selected':''); ?>>Inactivos</option>
        </select>
      </div>
      <div class="items-end flex">
        <button class="btn btn-secondary btn-sm">Aplicar</button>
      </div>
      <div class="spacer"></div>
      <a class="btn btn-primary btn-sm" href="<?php echo e(route('proveedores.create')); ?>">Nuevo</a>
    </form>
  </div>
</div>

<div class="card mt-2">
  <div class="card-body">
    <table class="table">
      <thead>
        <tr>
          <th>Proveedor</th><th>Empresa</th><th>Correo</th><th>Teléfono</th><th>Etiquetas</th><th>Estado</th><th style="width:220px">Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $prov; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($p->nombre); ?></td>
            <td><?php echo e($p->empresa ?? '—'); ?></td>
            <td class="muted"><?php echo e($p->correo); ?></td>
            <td class="muted"><?php echo e($p->telefono ?? '—'); ?></td>
            <td>
              <?php $__empty_2 = true; $__currentLoopData = $p->etiquetas_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                <span class="badge"><?php echo e($e); ?></span>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                <span class="muted">—</span>
              <?php endif; ?>
            </td>
            <td>
              <span class="badge <?php echo e($p->activo ? 'badge-ok' : 'badge-bad'); ?>"><?php echo e($p->activo ? 'Activo' : 'Inactivo'); ?></span>
            </td>
            <td class="flex gap-1">
              <a class="btn btn-secondary btn-sm" href="<?php echo e(route('proveedores.edit',$p->id_proveedor)); ?>">Editar</a>
              <a class="btn btn-primary btn-sm"  href="<?php echo e(route('proveedores.solicitud',$p->id_proveedor)); ?>">Solicitar</a>
              <form method="POST" action="<?php echo e(route('proveedores.toggle',$p->id_proveedor)); ?>" onsubmit="return confirm('¿Cambiar estado?')">
                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <button class="btn btn-sm"><?php echo e($p->activo ? 'Desactivar' : 'Activar'); ?></button>
              </form>
              <form method="POST" action="<?php echo e(route('proveedores.destroy',$p->id_proveedor)); ?>" onsubmit="return confirm('¿Eliminar proveedor?')">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-danger btn-sm">Eliminar</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="7">Sin proveedores.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>

    <div class="mt-2"><?php echo e($prov->links()); ?></div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/proveedores/index.blade.php ENDPATH**/ ?>