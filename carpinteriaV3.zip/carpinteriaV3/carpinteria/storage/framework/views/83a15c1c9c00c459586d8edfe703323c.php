
<?php $__env->startSection('contenido'); ?>
<h1>Productos</h1>
<?php if(session('ok')): ?> <div class="alert alert-ok mt-2"><?php echo e(session('ok')); ?></div> <?php endif; ?>

<div class="form-actions">
  <a href="<?php echo e(route('productos.create')); ?>" class="btn btn-primary">+ Nuevo</a>
</div>

<div class="mt-3 card">
  <div class="card-body">
    <table class="table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Foto</th>
          <th>Nombre</th>
          <th>Precio</th>
          <th>Estado</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($p->id_producto); ?></td>
            <td style="width:120px">
              <?php if($p->foto_url): ?>
                <img src="<?php echo e($p->foto_url); ?>" alt="Foto <?php echo e($p->nombre); ?>" style="width:120px; height:80px; object-fit:cover;">
              <?php else: ?> — <?php endif; ?>
            </td>
            <td><?php echo e($p->nombre); ?></td>
            <td>Q <?php echo e(number_format($p->precio_estimado,2)); ?></td>
            <td>
              <?php if($p->estado==='Activo'): ?>
                <span class="badge badge-ok">Activo</span>
              <?php else: ?>
                <span class="badge badge-warn">Inactivo</span>
              <?php endif; ?>
            </td>
            <td class="actions">
              <a class="btn btn-secondary btn-sm" href="<?php echo e(route('productos.edit', $p->id_producto)); ?>">Editar</a>
              <form action="<?php echo e(route('productos.destroy', $p->id_producto)); ?>" method="POST" onsubmit="return confirm('¿Eliminar producto?')">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6">Sin productos</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/productos/index.blade.php ENDPATH**/ ?>