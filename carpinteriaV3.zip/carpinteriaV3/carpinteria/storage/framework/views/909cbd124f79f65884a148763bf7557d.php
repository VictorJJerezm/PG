
<?php $__env->startSection('contenido'); ?>
<h1>Cotizaciones</h1>

<div class="form-actions">
  <a href="<?php echo e(route('gestion.cotizaciones.index')); ?>" class="btn btn-secondary btn-sm">Todas</a>
  <?php $__currentLoopData = ['Pendiente','Respondida','Aprobada','Rechazada','Cancelada']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('gestion.cotizaciones.index', ['estado'=>$st])); ?>" class="btn btn-secondary btn-sm"><?php echo e($st); ?></a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php if(session('ok')): ?> <div class="alert alert-ok mt-2"><?php echo e(session('ok')); ?></div> <?php endif; ?>
<?php if($errors->any()): ?> <div class="alert alert-bad mt-2"><?php echo e($errors->first()); ?></div> <?php endif; ?>

<div class="card mt-3">
  <div class="card-body">
    <table class="table">
      <thead>
        <tr>
          <th>#</th><th>Cliente</th><th>Fecha</th><th>Detalle</th><th>Estado</th><th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $cotizaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($c->id_cotizacion); ?></td>
            <td><?php echo e($c->cliente?->nombre ?? '—'); ?></td>
            <td><?php echo e($c->fecha); ?></td>
            <td>
            <?php $__currentLoopData = $c->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex items-center gap-2">
                <?php if($d->producto?->foto_url): ?>
                <img src="<?php echo e($d->producto->foto_url); ?>" alt="Foto <?php echo e($d->producto?->nombre); ?>" class="thumb-xs">
                <?php endif; ?>
                <div>
                <?php echo e($d->producto?->nombre ?? 'Producto'); ?>

                <?php if($d->material): ?> — <small class="muted"><?php echo e($d->material->nombre); ?></small><?php endif; ?>
                × <?php echo e($d->cantidad); ?>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td>
              <?php
                $badge = match($c->estado){
                  'Pendiente' => 'badge-warn',
                  'Respondida'=> 'badge-neutral',
                  'Aprobada'  => 'badge-ok',
                  'Rechazada' => 'badge-bad',
                  'Cancelada' => 'badge-bad',
                  default     => 'badge-neutral'
                };
              ?>
              <span class="badge <?php echo e($badge); ?>"><?php echo e($c->estado); ?></span>
            </td>

            <td class="actions">
              <a class="btn btn-secondary btn-sm" href="<?php echo e(route('gestion.cotizaciones.show',$c->id_cotizacion)); ?>">Ver</a>
              <?php if($c->estado==='Pendiente'): ?>
                <?php if($c->requiere_confirmacion_medidas): ?>
                  <div><small class="muted">Medidas: </small><span class="badge badge-warn">Requiere confirmación</span></div>
                <?php endif; ?>
                <a class="btn btn-primary btn-sm" href="<?php echo e(route('gestion.cotizaciones.form',$c->id_cotizacion)); ?>">Responder</a>
                <form method="POST" action="<?php echo e(route('gestion.cotizaciones.cancelar',$c->id_cotizacion)); ?>" onsubmit="return confirm('¿Cancelar cotización?')">
                  <?php echo csrf_field(); ?>
                  <button class="btn btn-danger btn-sm" type="submit">Cancelar</button>
                </form>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6">Sin cotizaciones</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/cotizaciones/admin/index.blade.php ENDPATH**/ ?>