
<?php $__env->startSection('contenido'); ?>
<h1>Insumos</h1>
<?php if(session('ok')): ?> <div class="alert alert-ok mt-2"><?php echo e(session('ok')); ?></div> <?php endif; ?>

<div class="form-actions">
  <a href="<?php echo e(route('insumos.create')); ?>" class="btn btn-primary">+ Nuevo insumo</a>
</div>

<div class="card mt-3">
  <div class="card-body">
    <table class="table">
      <thead>
        <tr>
          <th>ID</th><th>Nombre</th><th>Categoría</th><th>Unidad</th><th>Dimensiones</th><th>Precio ref.</th><th>Stock</th><th>Estado</th><th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $insumos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php
            $inv = $i->inventario;
            $stock = $inv?->cantidad ?? 0;
            $min = $inv?->stock_minimo ?? 5;
          ?>
          <tr>
            <td><?php echo e($i->id_insumo); ?></td>
            <td><?php echo e($i->nombre); ?></td>
            <td><?php echo e($i->categoria ?? 'material'); ?></td>
            <td><?php echo e($i->unidad ?? 'pieza'); ?></td>
            <td><?php echo e($i->largo ?? 0); ?> x <?php echo e($i->alto ?? 0); ?> x <?php echo e($i->ancho ?? 0); ?></td>
            <td>Q <?php echo e(number_format($i->precio,2)); ?></td>
            <td>
              <?php echo e($stock); ?>

              <?php if($stock < $min): ?>
                <span class="badge badge-bad">Bajo (min <?php echo e($min); ?>)</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if($i->estado==='Activo'): ?>
                <span class="badge badge-ok">Activo</span>
              <?php else: ?>
                <span class="badge badge-warn">Inactivo</span>
              <?php endif; ?>
            </td>
            <td class="actions">
              <a href="<?php echo e(route('insumos.edit', $i->id_insumo)); ?>" class="btn btn-secondary btn-sm">Editar</a>
              <form method="POST" action="<?php echo e(route('insumos.destroy', $i->id_insumo)); ?>" onsubmit="return confirm('¿Eliminar insumo?')">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="9">Sin insumos</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vjere\Desktop\carpinteriaV3\carpinteria\resources\views/insumos/index.blade.php ENDPATH**/ ?>